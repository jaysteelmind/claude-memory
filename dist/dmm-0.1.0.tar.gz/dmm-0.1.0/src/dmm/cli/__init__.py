"""DMM CLI module."""

from dmm.cli.main import app, main

__all__ = [
    "app",
    "main",
]
